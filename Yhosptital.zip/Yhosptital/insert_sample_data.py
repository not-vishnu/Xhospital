from app import app, db, User, Patient, Doctor, Nurse, Medicine, Appointment, Billing, Payment
from werkzeug.security import generate_password_hash
from datetime import datetime, date, timedelta

def insert_sample_data():
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()
        
        # Create Admin User
        admin = User(
            username='admin',
            email='admin@hospital.com',
            password_hash=generate_password_hash('admin123'),
            role='Admin'
        )
        db.session.add(admin)
        
        # Create Doctor Users
        doctor1_user = User(
            username='dr_rony',
            email='dr.rony@hospital.com',
            password_hash=generate_password_hash('doctor123'),
            role='Doctor'
        )
        db.session.add(doctor1_user)
        
        doctor2_user = User(
            username='dr_nandana',
            email='dr.nandana@hospital.com',
            password_hash=generate_password_hash('doctor123'),
            role='Doctor'
        )
        db.session.add(doctor2_user)
        
        # Create Nurse User
        nurse_user = User(
            username='nurse_meha',
            email='meha@hospital.com',
            password_hash=generate_password_hash('nurse123'),
            role='Nurse'
        )
        db.session.add(nurse_user)
        
        # Create Receptionist User
        receptionist_user = User(
            username='receptionist',
            email='reception@hospital.com',
            password_hash=generate_password_hash('reception123'),
            role='Receptionist'
        )
        db.session.add(receptionist_user)
        
        # Create Pharmacist User
        pharmacist_user = User(
            username='pharmacist',
            email='pharmacy@hospital.com',
            password_hash=generate_password_hash('pharmacy123'),
            role='Pharmacist'
        )
        db.session.add(pharmacist_user)
        
        # Create Accountant User
        accountant_user = User(
            username='accountant',
            email='accounts@hospital.com',
            password_hash=generate_password_hash('accounts123'),
            role='Accountant'
        )
        db.session.add(accountant_user)
        
        db.session.commit()
        
        # Create Doctor Profiles
        doctor1 = Doctor(
            user_id=doctor1_user.id,
            first_name='Rony',
            last_name='Jose',
            specialization='Cardiology',
            phone='555-0101'
        )
        db.session.add(doctor1)
        
        doctor2 = Doctor(
            user_id=doctor2_user.id,
            first_name='Nandana',
            last_name='Manoj',
            specialization='Pediatrics',
            phone='555-0102'
        )
        db.session.add(doctor2)
        
        # Create Nurse Profile
        nurse = Nurse(
            user_id=nurse_user.id,
            first_name='Meha',
            last_name='Sunny',
            assigned_ward='ICU',
            phone='555-0201'
        )
        db.session.add(nurse)
        
        # Create Sample Patients
        patients_data = [
            ('Jithu', 'Anil', '1985-03-15', 'Male', '555-1001', '123,valakom, City'),
            ('Shivashankar', 'KJ', '1990-07-22', 'Male', '555-1002', '321,valakom, City')
        ]
        
        for first_name, last_name, dob, gender, phone, address in patients_data:
            patient = Patient(
                first_name=first_name,
                last_name=last_name,
                dob=datetime.strptime(dob, '%Y-%m-%d').date(),
                gender=gender,
                phone=phone,
                address=address
            )
            db.session.add(patient)
        
        # Create Sample Medicines
        medicines_data = [
            ('Paracetamol', 'Pain reliever and fever reducer', 5.50, 100),
            ('Amoxicillin', 'Antibiotic for bacterial infections', 12.75, 50),
            ('Ibuprofen', 'Anti-inflammatory pain reliever', 8.25, 75),
            ('Aspirin', 'Pain reliever and blood thinner', 6.00, 80),
            ('Cough Syrup', 'Relief for cough and cold symptoms', 9.99, 30)
        ]
        
        for name, description, price, stock in medicines_data:
            medicine = Medicine(
                name=name,
                description=description,
                price=price,
                stock=stock
            )
            db.session.add(medicine)
        
        db.session.commit()
        
        # Create Sample Appointments
        appointments_data = [
            (1, 1, datetime.now() + timedelta(days=1, hours=10)),
            (2, 2, datetime.now() + timedelta(days=2, hours=14))
        ]
        
        for patient_id, doctor_id, appointment_date in appointments_data:
            appointment = Appointment(
                patient_id=patient_id,
                doctor_id=doctor_id,
                appointment_date=appointment_date
            )
            db.session.add(appointment)
        
        db.session.commit()
        
        # Create Sample Bills
        bills_data = [
            (1, 150.00),
            (2, 200.50)
        ]
        
        for patient_id, amount in bills_data:
            bill = Billing(
                patient_id=patient_id,
                amount=amount
            )
            db.session.add(bill)
        
        db.session.commit()
        
        print("Sample data inserted successfully!")
        print("\nLogin Credentials:")
        print("Admin: admin / admin123")
        print("Doctor: dr_rony / doctor123")
        print("Doctor: dr_nandana / doctor123")
        print("Nurse: nurse_meha / nurse123")
        print("Receptionist: receptionist / reception123")
        print("Pharmacist: pharmacist / pharmacy123")
        print("Accountant: accountant / accounts123")

if __name__ == '__main__':
    insert_sample_data()