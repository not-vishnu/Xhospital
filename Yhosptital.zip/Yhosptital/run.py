#!/usr/bin/env python3
"""
Hospital Management System - Run Script
"""

import os
import sys
from app import app, db

def create_tables():
    """Create database tables if they don't exist"""
    with app.app_context():
        try:
            db.create_all()
            print("✓ Database tables created successfully")
        except Exception as e:
            print(f"✗ Error creating tables: {e}")
            return False
    return True

def check_dependencies():
    """Check if all required packages are installed"""
    try:
        import flask
        import flask_sqlalchemy
        import flask_login
        import flask_wtf
        import pymysql
        print("✓ All dependencies are installed")
        return True
    except ImportError as e:
        print(f"✗ Missing dependency: {e}")
        print("Please run: pip install -r requirements.txt")
        return False

def main():
    """Main function to run the application"""
    print("=" * 50)
    print("Hospital Management System")
    print("=" * 50)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Create tables
    if not create_tables():
        sys.exit(1)
    
    # Check if sample data exists
    with app.app_context():
        from app import User
        if User.query.count() == 0:
            print("\n⚠ No users found in database.")
            print("Run 'python insert_sample_data.py' to add sample data")
            print("Or create an admin user manually")
    
    print("\n" + "=" * 50)
    print("Starting Hospital Management System...")
    print("Access the application at: http://localhost:5000")
    print("Press Ctrl+C to stop the server")
    print("=" * 50 + "\n")
    
    # Run the Flask application
    try:
        app.run(debug=True, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        print("\n\nServer stopped by user")
    except Exception as e:
        print(f"\n✗ Error starting server: {e}")

if __name__ == '__main__':
    main()