from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date
from config import Config
import os

app = Flask(__name__)
app.config.from_object(Config)

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Models
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum('Admin', 'Doctor', 'Receptionist', 'Accountant', 'Pharmacist', 'Nurse'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Patient(db.Model):
    __tablename__ = 'patients'
    patient_id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    dob = db.Column(db.Date, nullable=False)
    gender = db.Column(db.Enum('Male', 'Female', 'Other'), nullable=False)
    phone = db.Column(db.String(15))
    address = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Doctor(db.Model):
    __tablename__ = 'doctors'
    doctor_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True, nullable=False)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    specialization = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(15))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship('User', backref='doctor_profile')

class Nurse(db.Model):
    __tablename__ = 'nurses'
    nurse_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True, nullable=False)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    assigned_ward = db.Column(db.String(100))
    phone = db.Column(db.String(15))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship('User', backref='nurse_profile')

class Appointment(db.Model):
    __tablename__ = 'appointments'
    appointment_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False)
    appointment_date = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.Enum('Scheduled', 'Completed', 'Cancelled'), default='Scheduled')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    patient = db.relationship('Patient', backref='appointments')
    doctor = db.relationship('Doctor', backref='appointments')

class Medicine(db.Model):
    __tablename__ = 'medicines'
    medicine_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.String(255))
    price = db.Column(db.Numeric(10, 2), nullable=False)
    stock = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Prescription(db.Model):
    __tablename__ = 'prescriptions'
    prescription_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    patient = db.relationship('Patient', backref='prescriptions')
    doctor = db.relationship('Doctor', backref='prescriptions')

class PrescriptionItem(db.Model):
    __tablename__ = 'prescription_items'
    id = db.Column(db.Integer, primary_key=True)
    prescription_id = db.Column(db.Integer, db.ForeignKey('prescriptions.prescription_id'), nullable=False)
    medicine_id = db.Column(db.Integer, db.ForeignKey('medicines.medicine_id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    prescription = db.relationship('Prescription', backref='items')
    medicine = db.relationship('Medicine', backref='prescription_items')

class Billing(db.Model):
    __tablename__ = 'billing'
    bill_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id'), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    status = db.Column(db.Enum('Unpaid', 'Paid'), default='Unpaid')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    patient = db.relationship('Patient', backref='bills')

class Payment(db.Model):
    __tablename__ = 'payments'
    payment_id = db.Column(db.Integer, primary_key=True)
    bill_id = db.Column(db.Integer, db.ForeignKey('billing.bill_id'), nullable=False)
    amount_paid = db.Column(db.Numeric(10, 2), nullable=False)
    payment_method = db.Column(db.String(50), nullable=False)
    transaction_id = db.Column(db.String(100))
    payment_notes = db.Column(db.Text)
    payment_date = db.Column(db.DateTime, default=datetime.utcnow)
    bill = db.relationship('Billing', backref='payments')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def role_required(roles):
    def decorator(f):
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated or current_user.role not in roles:
                flash('Access denied. Insufficient permissions.', 'error')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        decorated_function.__name__ = f.__name__
        return decorated_function
    return decorator

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid username or password', 'error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    stats = {
        'patients': Patient.query.count(),
        'doctors': Doctor.query.count(),
        'appointments': Appointment.query.count(),
        'medicines': Medicine.query.count()
    }
    return render_template('dashboard.html', stats=stats)

# User Management Routes
@app.route('/users')
@login_required
@role_required(['Admin'])
def users_list():
    users = User.query.all()
    return render_template('users/list.html', users=users)

@app.route('/users/create', methods=['GET', 'POST'])
@login_required
@role_required(['Admin'])
def users_create():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return render_template('users/create.html')
        
        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password),
            role=role
        )
        db.session.add(user)
        db.session.commit()
        
        # Create role-specific profile
        if role == 'Doctor':
            doctor = Doctor(
                user_id=user.id,
                first_name=request.form.get('first_name', ''),
                last_name=request.form.get('last_name', ''),
                specialization=request.form.get('specialization', ''),
                phone=request.form.get('phone', '')
            )
            db.session.add(doctor)
        elif role == 'Nurse':
            nurse = Nurse(
                user_id=user.id,
                first_name=request.form.get('first_name', ''),
                last_name=request.form.get('last_name', ''),
                assigned_ward=request.form.get('assigned_ward', ''),
                phone=request.form.get('phone', '')
            )
            db.session.add(nurse)
        
        db.session.commit()
        flash('User created successfully', 'success')
        return redirect(url_for('users_list'))
    
    return render_template('users/create.html')

@app.route('/users/edit/<int:user_id>', methods=['GET', 'POST'])
@login_required
@role_required(['Admin'])
def users_edit(user_id):
    user = User.query.get_or_404(user_id)
    if request.method == 'POST':
        user.username = request.form['username']
        user.email = request.form['email']
        user.role = request.form['role']
        if request.form['password']:
            user.password_hash = generate_password_hash(request.form['password'])
        db.session.commit()
        flash('User updated successfully', 'success')
        return redirect(url_for('users_list'))
    
    return render_template('users/edit.html', user=user)

# Patient Management Routes
@app.route('/patients')
@login_required
def patients_list():
    patients = Patient.query.all()
    return render_template('patients/list.html', patients=patients)

@app.route('/patients/create', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Receptionist', 'Doctor', 'Nurse'])
def patients_create():
    if request.method == 'POST':
        patient = Patient(
            first_name=request.form['first_name'],
            last_name=request.form['last_name'],
            dob=datetime.strptime(request.form['dob'], '%Y-%m-%d').date(),
            gender=request.form['gender'],
            phone=request.form['phone'],
            address=request.form['address']
        )
        db.session.add(patient)
        db.session.commit()
        flash('Patient added successfully', 'success')
        return redirect(url_for('patients_list'))
    
    return render_template('patients/create.html')

@app.route('/patients/edit/<int:patient_id>', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Receptionist', 'Doctor', 'Nurse'])
def patients_edit(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    if request.method == 'POST':
        patient.first_name = request.form['first_name']
        patient.last_name = request.form['last_name']
        patient.dob = datetime.strptime(request.form['dob'], '%Y-%m-%d').date()
        patient.gender = request.form['gender']
        patient.phone = request.form['phone']
        patient.address = request.form['address']
        db.session.commit()
        flash('Patient updated successfully', 'success')
        return redirect(url_for('patients_list'))
    
    return render_template('patients/edit.html', patient=patient)

@app.route('/patients/view/<int:patient_id>')
@login_required
@role_required(['Admin', 'Receptionist', 'Doctor', 'Nurse'])
def patients_view(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    return render_template('patients/view.html', patient=patient)

@app.route('/appointments/edit/<int:appointment_id>', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Receptionist', 'Doctor'])
def appointments_edit(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    if request.method == 'POST':
        appointment.patient_id = request.form['patient_id']
        appointment.doctor_id = request.form['doctor_id']
        date_str = request.form['appointment_date'] + 'T' + request.form['appointment_time']
        appointment.appointment_date = datetime.strptime(date_str, '%Y-%m-%dT%H:%M')
        appointment.status = request.form['status']
        db.session.commit()
        flash('Appointment updated successfully', 'success')
        return redirect(url_for('appointments_list'))
    
    patients = Patient.query.all()
    doctors = Doctor.query.all()
    return render_template('appointments/edit.html', appointment=appointment, patients=patients, doctors=doctors)

# Appointment Management Routes
@app.route('/appointments')
@login_required
def appointments_list():
    appointments = Appointment.query.all()
    return render_template('appointments/list.html', appointments=appointments)

@app.route('/appointments/create', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Receptionist', 'Doctor'])
def appointments_create():
    if request.method == 'POST':
        appointment = Appointment(
            patient_id=request.form['patient_id'],
            doctor_id=request.form['doctor_id'],
            appointment_date=datetime.strptime(request.form['appointment_date'], '%Y-%m-%dT%H:%M')
        )
        db.session.add(appointment)
        db.session.commit()
        flash('Appointment scheduled successfully', 'success')
        return redirect(url_for('appointments_list'))
    
    patients = Patient.query.all()
    doctors = Doctor.query.all()
    return render_template('appointments/create.html', patients=patients, doctors=doctors)

# Medicine Management Routes
@app.route('/medicines')
@login_required
@role_required(['Admin', 'Pharmacist', 'Doctor'])
def medicines_list():
    medicines = Medicine.query.all()
    return render_template('medicines/list.html', medicines=medicines)

@app.route('/medicines/create', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Pharmacist'])
def medicines_create():
    if request.method == 'POST':
        medicine = Medicine(
            name=request.form['name'],
            description=request.form['description'],
            price=float(request.form['price']),
            stock=int(request.form['stock'])
        )
        db.session.add(medicine)
        db.session.commit()
        flash('Medicine added successfully', 'success')
        return redirect(url_for('medicines_list'))
    
    return render_template('medicines/create.html')

@app.route('/medicines/edit/<int:medicine_id>', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Pharmacist'])
def medicines_edit(medicine_id):
    medicine = Medicine.query.get_or_404(medicine_id)
    if request.method == 'POST':
        medicine.name = request.form['name']
        medicine.description = request.form['description']
        medicine.price = float(request.form['price'])
        medicine.stock = int(request.form['stock'])
        db.session.commit()
        flash('Medicine updated successfully', 'success')
        return redirect(url_for('medicines_list'))
    
    return render_template('medicines/edit.html', medicine=medicine)

# Billing Management Routes
@app.route('/billing')
@login_required
@role_required(['Admin', 'Accountant', 'Receptionist'])
def billing_list():
    bills = Billing.query.all()
    return render_template('billing/list.html', bills=bills)

@app.route('/billing/create', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Accountant', 'Receptionist'])
def billing_create():
    if request.method == 'POST':
        bill = Billing(
            patient_id=request.form['patient_id'],
            amount=float(request.form['amount'])
        )
        db.session.add(bill)
        db.session.commit()
        flash('Bill created successfully', 'success')
        return redirect(url_for('billing_list'))
    
    patients = Patient.query.all()
    return render_template('billing/create.html', patients=patients)

@app.route('/billing/edit/<int:bill_id>', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Accountant', 'Receptionist'])
def billing_edit(bill_id):
    bill = Billing.query.get_or_404(bill_id)
    if request.method == 'POST':
        bill.patient_id = request.form['patient_id']
        bill.amount = float(request.form['amount'])
        bill.status = request.form['status']
        db.session.commit()
        flash('Bill updated successfully', 'success')
        return redirect(url_for('billing_list'))
    
    patients = Patient.query.all()
    return render_template('billing/edit.html', bill=bill, patients=patients)

@app.route('/billing/view/<int:bill_id>')
@login_required
@role_required(['Admin', 'Accountant', 'Receptionist'])
def billing_view(bill_id):
    bill = Billing.query.get_or_404(bill_id)
    return render_template('billing/view.html', bill=bill)

@app.route('/billing/payment/<int:bill_id>', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Accountant', 'Receptionist'])
def billing_payment(bill_id):
    bill = Billing.query.get_or_404(bill_id)
    
    if bill.status == 'Paid':
        flash('This bill has already been paid', 'warning')
        return redirect(url_for('billing_list'))
    
    if request.method == 'POST':
        # Create payment record
        payment = Payment(
            bill_id=bill_id,
            amount_paid=float(request.form['amount_paid']),
            payment_method=request.form['payment_method'],
            transaction_id=request.form.get('transaction_id'),
            payment_notes=request.form.get('payment_notes')
        )
        
        # Update bill status
        bill.status = 'Paid'
        
        db.session.add(payment)
        db.session.commit()
        
        flash(f'Payment of RS {payment.amount_paid} processed successfully via {payment.payment_method}', 'success')
        return redirect(url_for('billing_list'))
    
    return render_template('billing/payment.html', bill=bill)

# Prescription Management Routes
@app.route('/prescriptions')
@login_required
@role_required(['Admin', 'Doctor', 'Pharmacist'])
def prescriptions_list():
    prescriptions = Prescription.query.all()
    return render_template('prescriptions/list.html', prescriptions=prescriptions)

@app.route('/prescriptions/create', methods=['GET', 'POST'])
@login_required
@role_required(['Admin', 'Doctor'])
def prescriptions_create():
    if request.method == 'POST':
        prescription = Prescription(
            patient_id=request.form['patient_id'],
            doctor_id=request.form['doctor_id'],
            date=date.today(),
            notes=request.form['notes']
        )
        db.session.add(prescription)
        db.session.commit()
        flash('Prescription created successfully', 'success')
        return redirect(url_for('prescriptions_list'))
    
    patients = Patient.query.all()
    doctors = Doctor.query.all()
    return render_template('prescriptions/create.html', patients=patients, doctors=doctors)

@app.route('/prescriptions/view/<int:prescription_id>')
@login_required
@role_required(['Admin', 'Doctor', 'Pharmacist'])
def prescriptions_view(prescription_id):
    prescription = Prescription.query.get_or_404(prescription_id)
    return render_template('prescriptions/view.html', prescription=prescription)

# Reports and Export Routes
@app.route('/reports')
@login_required
@role_required(['Admin', 'Accountant'])
def reports_list():
    stats = {
        'total_patients': Patient.query.count(),
        'total_appointments': Appointment.query.count(),
        'total_revenue': f"RS {db.session.query(db.func.sum(Billing.amount)).filter(Billing.status == 'Paid').scalar() or 0:.2f}",
        'pending_bills': Billing.query.filter_by(status='Unpaid').count()
    }
    return render_template('reports/list.html', stats=stats)

@app.route('/export/patients')
@login_required
@role_required(['Admin', 'Accountant'])
def export_patients():
    from flask import make_response
    import csv
    import io
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'First Name', 'Last Name', 'DOB', 'Gender', 'Phone', 'Address'])
    
    patients = Patient.query.all()
    for patient in patients:
        writer.writerow([patient.patient_id, patient.first_name, patient.last_name, 
                        patient.dob, patient.gender, patient.phone, patient.address])
    
    response = make_response(output.getvalue())
    response.headers['Content-Type'] = 'text/csv'
    response.headers['Content-Disposition'] = 'attachment; filename=patients.csv'
    return response

@app.route('/export/appointments')
@login_required
@role_required(['Admin', 'Accountant'])
def export_appointments():
    from flask import make_response
    import csv
    import io
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Patient', 'Doctor', 'Date', 'Status'])
    
    appointments = Appointment.query.all()
    for apt in appointments:
        writer.writerow([apt.appointment_id, f"{apt.patient.first_name} {apt.patient.last_name}",
                        f"Dr. {apt.doctor.first_name} {apt.doctor.last_name}",
                        apt.appointment_date, apt.status])
    
    response = make_response(output.getvalue())
    response.headers['Content-Type'] = 'text/csv'
    response.headers['Content-Disposition'] = 'attachment; filename=appointments.csv'
    return response

@app.route('/export/medicines')
@login_required
@role_required(['Admin', 'Pharmacist'])
def export_medicines():
    from flask import make_response
    import csv
    import io
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Name', 'Description', 'Price', 'Stock'])
    
    medicines = Medicine.query.all()
    for medicine in medicines:
        writer.writerow([medicine.medicine_id, medicine.name, medicine.description,
                        medicine.price, medicine.stock])
    
    response = make_response(output.getvalue())
    response.headers['Content-Type'] = 'text/csv'
    response.headers['Content-Disposition'] = 'attachment; filename=medicines.csv'
    return response

@app.route('/export/billing')
@login_required
@role_required(['Admin', 'Accountant'])
def export_billing():
    from flask import make_response
    import csv
    import io
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Bill ID', 'Patient', 'Amount', 'Status', 'Date'])
    
    bills = Billing.query.all()
    for bill in bills:
        writer.writerow([bill.bill_id, f"{bill.patient.first_name} {bill.patient.last_name}",
                        bill.amount, bill.status, bill.created_at.strftime('%Y-%m-%d')])
    
    response = make_response(output.getvalue())
    response.headers['Content-Type'] = 'text/csv'
    response.headers['Content-Disposition'] = 'attachment; filename=billing.csv'
    return response

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)