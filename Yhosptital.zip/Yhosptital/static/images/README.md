# Images Directory

This directory contains static images for the Hospital Management System.

## Required Images

1. **hospital-bg.jpg** - Background image for the landing page
   - Recommended size: 1200x800 pixels
   - Should show a professional hospital or medical facility
   - You can download a free image from:
     - Unsplash.com
     - Pexels.com
     - Pixabay.com

## Adding Images

1. Download a suitable hospital background image
2. Rename it to `hospital-bg.jpg`
3. Place it in this directory (`static/images/`)

The application will automatically use this image on the landing page.